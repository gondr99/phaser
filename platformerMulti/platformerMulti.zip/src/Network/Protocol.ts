import {Socket} from 'socket.io-client';

export interface Position 
{
    x:number;
    y:number;
}

export default (socket:Socket) => {
    
};